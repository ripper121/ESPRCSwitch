/*
  ESPiLight - pilight 433.92 MHz protocols library for Arduino
  Copyright (c) 2016 Puuu.  All right reserved.

  Project home: https://github.com/puuu/espilight/
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 3 of the License, or (at your option) any later version.
  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with library. If not, see <http://www.gnu.org/licenses/>
*/

#include <Arduino.h>
#include "aprintf.h"

#ifdef PILIGHT_PRINT

#define BUFFER_SIZE 32

int aprintf(const char *format, ...) {
  char buffer[BUFFER_SIZE] = {0};
  va_list args;
  va_start(args, format);
  vsnprintf(buffer, BUFFER_SIZE, format, args);
  va_end(args);
  PILIGHT_PRINT.print(buffer);
}

void exit(int n) {
  ESP.restart();
}

#endif
